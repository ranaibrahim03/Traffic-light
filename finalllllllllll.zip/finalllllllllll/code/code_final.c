#define  choose  porte.B2

#define  seg_1  porta.B1
#define  seg_2  porta.B2

#define r1 portd.b0
#define y1 portd.b1
#define g1 portd.b2

#define r2 portd.b3
#define y2 portd.b4
#define g2 portd.b5

#define seg_1 porta.b1
#define seg_2 porta.b2

char j ;  //global

  //prototype of functions
void manual();
void autoo();

  //intertupt
void interrupt(){

  if(intf_bit == 1){
          intf_bit = 0 ;
          manual();
  }
}

void main() {

            adcon1 = 7 ;      //convert all bits to digital

            trisa.B1  = 0 ;
            trisa.B2  = 0 ;
            trisb.b0  = 1 ;
            trisc     = 0 ;
            trisd     = 0 ;

            porta  = 0 ;
            portc  = 0 ;
            portd  = 0 ;

            //interrupt on B0
            gie_bit    = 1 ;
            inte_bit   = 1 ;
            intedg_bit = 1 ;


             while(1){

                 autoo();   //turn on auto mode as default

             }

}

 //auto mode function
void autoo(){

              seg_1 = 1 ;    //turn on seven segment
              seg_2 = 1 ;
              portd = 0 ;   //reset all leds

            while(1){

                  for(j = 15 ; ; --j ){
                            r2 = 1 ;
                            if(j > 3 )    g1 = 1 ;
                            else          y1 = 1 ;

                           portc = dec2bcd(j);
                           delay_ms(1000);

                             portd = 0 ;
                           if(j == 1 ) break;  //condition

                      }

                  for(j = 23  ; ; --j ){
                           r1 = 1 ;
                           if(j > 3 )   g2 = 1 ;
                           else          y2 = 1 ;

                           portc = dec2bcd(j); //used dec2bcd(); to convert the
                           delay_ms(1000);     //decimal to bcd representation
                            portd = 0 ;

                            if(j == 1 ) break;  //condition

                      }



              }
            seg_1 = 0 ;  //turn off seven segment
            seg_2 = 0 ;

 }

void manual(){

            seg_1 = 0 ;  //turn off seven segment
            seg_2 = 0 ;
            portd = 0 ;   //reset all leds

       while(1){

             g1 = 1 ;
             r2 = 1 ;

             while(choose == 0); //wait untill switch is pressed and change street

             portd = 0 ;
             y1 = 1 ;
             r2 = 1 ;
             delay_ms(3000);
             portd = 0 ;
             g2 = 1 ;
             r1 = 1 ;

            while(choose == 0);  //wait untill switch is pressed and change street

            portd = 0 ;
            y2 = 1 ;
            r1 = 1 ;
            delay_ms(3000);
            portd = 0 ;

        }
}